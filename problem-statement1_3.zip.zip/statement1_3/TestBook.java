package com.problem.statement1_3;
public class TestBook {
	
	public void createbook() {
		Book b[]=new Book[2];
		b[0]=new Book("Java Programming",350.50);
		b[1]=new Book("Let Us C",200.00);
		for(int i=0;i<b.length;i++)
		{
			b[i].Display();
			System.out.println(" ");
		}
	}
	public void ShowBook() {
		createbook();
	}
	public static void main(String[] args) {
		TestBook m=new TestBook();
		m.ShowBook();
	}
		

}